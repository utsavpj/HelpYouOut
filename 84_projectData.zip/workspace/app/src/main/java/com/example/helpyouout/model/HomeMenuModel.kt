package com.example.helpyouout.model

import java.io.Serializable

data class HomeMenuModel(var name: String, var image: Int) : Serializable